<?php

class Auth
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function login($email, $password)
    {
        $email = filter_var($email, FILTER_SANITIZE_STRING); 
        $password = sha1($password);
        $password = filter_var($password, FILTER_SANITIZE_STRING);

        $select_users = $this->conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ? LIMIT 1");
        $select_users->execute([$email, $password]);
        $row = $select_users->fetch(PDO::FETCH_ASSOC);

        if ($select_users->rowCount() > 0) {
            setcookie('user_id', $row['id'], time() + 60*60*24*30, '/');
            return true;
        } else {
            return false;
        }
    }
}

?>
