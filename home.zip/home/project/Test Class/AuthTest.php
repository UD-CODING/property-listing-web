<?php

use PHPUnit\Framework\TestCase;

class AuthTest extends TestCase
{
    private $conn;
    private $auth;

    protected function setUp(): void
    {
        // Mock the PDO connection
        $this->conn = $this->createMock(PDO::class);
        $this->auth = new Auth($this->conn);
    }

    public function testLoginWithValidCredentials()
    {
        $email = 'valid@example.com';
        $password = 'validpassword';

        // Mock the PDOStatement
        $stmt = $this->createMock(PDOStatement::class);

        // Setup the expectation for the prepare and execute methods
        $this->conn->expects($this->once())
                   ->method('prepare')
                   ->with("SELECT * FROM `users` WHERE email = ? AND password = ? LIMIT 1")
                   ->willReturn($stmt);

        $stmt->expects($this->once())
             ->method('execute')
             ->with([$email, sha1($password)]);

        $stmt->expects($this->once())
             ->method('fetch')
             ->willReturn(['id' => 1]);

        $stmt->expects($this->once())
             ->method('rowCount')
             ->willReturn(1);

        $result = $this->auth->login($email, $password);
        $this->assertTrue($result);
    }

    public function testLoginWithInvalidCredentials()
    {
        $email = 'invalid@example.com';
        $password = 'invalidpassword';

        // Mock the PDOStatement
        $stmt = $this->createMock(PDOStatement::class);

        // Setup the expectation for the prepare and execute methods
        $this->conn->expects($this->once())
                   ->method('prepare')
                   ->with("SELECT * FROM `users` WHERE email = ? AND password = ? LIMIT 1")
                   ->willReturn($stmt);

        $stmt->expects($this->once())
             ->method('execute')
             ->with([$email, sha1($password)]);

        $stmt->expects($this->once())
             ->method('fetch')
             ->willReturn(false);

        $stmt->expects($this->once())
             ->method('rowCount')
             ->willReturn(0);

        $result = $this->auth->login($email, $password);
        $this->assertFalse($result);
    }
}

class Auth
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function login($email, $password)
    {
        $email = filter_var($email, FILTER_SANITIZE_STRING); 
        $password = sha1($password);
        $password = filter_var($password, FILTER_SANITIZE_STRING);

        $select_users = $this->conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ? LIMIT 1");
        $select_users->execute([$email, $password]);
        $row = $select_users->fetch(PDO::FETCH_ASSOC);

        if ($select_users->rowCount() > 0) {
            setcookie('user_id', $row['id'], time() + 60*60*24*30, '/');
            return true;
        } else {
            return false;
        }
    }
}

?>

