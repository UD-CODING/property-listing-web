<?php

use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        // Mock database connection using PDO
        $this->conn = $this->createMock(PDO::class);
    }

    public function testSuccessfulLogin()
    {
        // Mock the database interaction
        $email = 'test@example.com';
        $password = sha1('password');

        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn([
            'id' => 1,
            'email' => $email,
            'password' => $password
        ]);
        $stmt->method('rowCount')->willReturn(1);

        $this->conn->method('prepare')->willReturn($stmt);

        $_POST['email'] = $email;
        $_POST['pass'] = 'password';
        $_POST['submit'] = true;

        // Include your login script here or require it
        include 'login_script.php';

        // Assert the expected result
        $this->assertEquals(1, $_COOKIE['user_id']);
        $this->assertEquals('home.php', $location);
    }

    public function testFailedLogin()
    {
        // Mock the database interaction
        $email = 'wrong@example.com';
        $password = sha1('wrongpassword');

        $stmt = $this->createMock(PDOStatement::class);
        $stmt->method('execute')->willReturn(true);
        $stmt->method('fetch')->willReturn(false);
        $stmt->method('rowCount')->willReturn(0);

        $this->conn->method('prepare')->willReturn($stmt);

        $_POST['email'] = $email;
        $_POST['pass'] = 'wrongpassword';
        $_POST['submit'] = true;

        // Include your login script here or require it
        include 'login_script.php';

        // Assert that the warning message was set
        $this->assertContains('Incorrect username or password!', $warning_msg);
    }
}
