<?php

use PHPUnit\Framework\TestCase;

class ContactPageTest extends TestCase
{
    private $conn;
    private $pdoStatement;

    protected function setUp(): void
    {
        // Mock PDO and PDOStatement
        $this->pdoStatement = $this->createMock(PDOStatement::class);
        $this->conn = $this->createMock(PDO::class);

        // Set up the mock PDO to return the mock statement
        $this->conn->method('prepare')->willReturn($this->pdoStatement);
    }

    public function testMessageAlreadySent()
    {
        // Mock POST data
        $_POST['send'] = true;
        $_POST['name'] = 'John Doe';
        $_POST['email'] = 'johndoe@example.com';
        $_POST['number'] = '1234567890';
        $_POST['message'] = 'Test message';

        // Mock database interactions
        $this->pdoStatement->method('execute')->willReturn(true);
        $this->pdoStatement->method('rowCount')->willReturn(1); // Simulate existing message

        // Include the contact script
        ob_start();
        include 'contact.php'; // Your script's filename
        ob_end_clean();

        // Check if the warning message is set
        global $warning_msg;
        $this->assertContains('message sent already!', $warning_msg);
    }

    public function testMessageSendSuccessfully()
    {
        // Mock POST data
        $_POST['send'] = true;
        $_POST['name'] = 'Jane Doe';
        $_POST['email'] = 'janedoe@example.com';
        $_POST['number'] = '0987654321';
        $_POST['message'] = 'Test message';

        // Mock database interactions
        $this->pdoStatement->method('execute')->willReturn(true);
        $this->pdoStatement->method('rowCount')->willReturn(0); // Simulate no existing message

        // Include the contact script
        ob_start();
        include 'contact.php'; // Your script's filename
        ob_end_clean();

        // Check if the success message is set
        global $success_msg;
        $this->assertContains('message send successfully!', $success_msg);
    }

    public function testMessageSanitization()
    {
        // Mock POST data with unsanitized inputs
        $_POST['send'] = true;
        $_POST['name'] = '<script>alert(1)</script>';
        $_POST['email'] = '<script>alert(1)</script>@example.com';
        $_POST['number'] = '1234567890';
        $_POST['message'] = '<script>alert(1)</script>';

        // Mock database interactions
        $this->pdoStatement->method('execute')->willReturn(true);
        $this->pdoStatement->method('rowCount')->willReturn(0); // Simulate no existing message

        // Include the contact script
        ob_start();
        include 'contact.php'; // Your script's filename
        ob_end_clean();

        // Check if the inputs are sanitized
        $this->assertNotEquals('<script>alert(1)</script>', $_POST['name']);
        $this->assertNotEquals('<script>alert(1)</script>@example.com', $_POST['email']);
        $this->assertNotEquals('<script>alert(1)</script>', $_POST['message']);
    }
}
